<?php
/*
	session_start();
		
	$login_user = "";
	
	if (isset($_SESSION['tashrihi_evaluator_login']))
	{
		$login_user = $_SESSION['tashrihi_evaluator_login'];
	}
	else
	{
		exit;
	}
	
*/

	$file_name = $_GET['file_name'];
	$file_name = "t_page/$file_name";
	
	$b_px=$_GET['b_px'];
	$e_px=$_GET['e_px'];
	
	$image_data = getimagesize ( $file_name);
	
	$img_width = $image_data[0];
	$img_height = $image_data[1];
	

	
	// Create image instances
	$src = imagecreatefrompng ($file_name);
	$dest = imagecreatetruecolor($img_width, intval((($e_px-$b_px)/100)*$img_height));

	// Copy
	imagecopy($dest, $src, 0, 0, 0, intval(($b_px/100)*$img_height), $img_width, intval((($e_px-$b_px)/100)*$img_height));

	// Output and free from memory
	header('Content-Type: image/gif');
	imagegif($dest);

	imagedestroy($dest);
	imagedestroy($src);

?>