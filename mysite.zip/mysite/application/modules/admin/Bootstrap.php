<?php

class Admin_Bootstrap extends Zend_Application_Module_Bootstrap
{

    protected function _initHelperPath()
    {
        Zend_Controller_Action_HelperBroker::addPath(
            APPLICATION_PATH . '/modules/admin/controllers/helpers',
            'Admin_Controller_Action_Helper_');

    }

}

