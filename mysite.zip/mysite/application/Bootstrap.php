<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{

	protected function _initAutoloader()
	{	
		$autoloader = Zend_Loader_Autoloader::getInstance();
		$autoloader->registerNamespace('Module_');
	}
	
	protected function _initSetupLayout(){
		//setup the layout
		Zend_Layout::startMvc(array(
			'layoutPath' => '../application/modules/default/layouts/scripts',
			'layout' => 'layout'
		));
		 
		$layoutModulePlugin = new Module_LayoutPlugin();
		$layoutModulePlugin->registerModuleLayout('admin','../application/modules/admin/layouts/scripts');
		$controller = Zend_Controller_Front::getInstance(); 
		$controller->registerPlugin($layoutModulePlugin);
	}

	protected function _initFhyyyb()
	{
		$ar = $this->getOption('resources');

		$params = array(
			'host'     => strval($ar['db']['params']['host']),
			'username' => strval($ar['db']['params']['username']),
			'password' => strval($ar['db']['params']['password']),
			'dbname'   => strval($ar['db']['params']['dbname']),
			'charset'  => strval($ar['db']['params']['charset'])
		);


		$params['profiler'] = true;
		$db = Zend_Db::factory('PDO_MYSQL', $params);
		$db->getProfiler()->setEnabled(true);
		Zend_Registry::set('mydb', $db);

	}



}

