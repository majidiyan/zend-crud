<?php
class controllerCreator{
    
    private $table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2 ;
    
    public $classController, $indexAction, $requestpagesAction, $requestupdateAction;
    
    private $sampleFile;
    
    function __construct($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
        $this->table = $table;
        $this->colNamesAr1 = $colNamesAr1;
        $this->colTypesAr1 = $colTypesAr1;
        $this->colNamesAr2 = $colNamesAr2;
        $this->keyNamesAr2 = $keyNamesAr2;
        $this->isUniqueAr2 = $isUniqueAr2;
        
        $this->sampleFile = '';
        $fp = fopen("lib/controllers/Sample.txt","r");
            for($i = 1; $i <= 228; $i++)
                $this->sampleFile = $this->sampleFile.fgets($fp,2000);
        fclose($fp);
    }
    
    
    public function generateClassController(){
       $this->classController = '';
       $pdoTable = ucfirst( ltrim($this->table,'tbl_') );
       $auxAr = explode("/*part_1*/", $this->sampleFile);
       $this->classController = str_replace('Evaluator',$pdoTable, $auxAr[1]);
    }
    
    public function generateIndexAction(){
        $this->indexAction = '';
        $pdoTable = ucfirst( ltrim($this->table,'tbl_') );
        $auxAr = explode("/*part_2*/", $this->sampleFile);
        $part2 = $auxAr[1];
        $part2 = str_replace('Evaluator',$pdoTable, $part2 );
        $part2 = str_replace('evaluator',  strtolower($pdoTable), $part2 );
        
        $auxAr = explode("/*part_3*/", $this->sampleFile);
        $part3 = $auxAr[1];
        $part3 = str_replace('Evaluator',$pdoTable, $part3 );
        $part3 = str_replace('evaluator',  strtolower($pdoTable), $part3 );
        
        $part4 = '';
        
        $part5 = '';
        $part6 = '';
        
        $j = -1; 
        foreach ($this->colNamesAr1 as $m){
            $j++;
	    $pk = false;
           // ======== M ======================
            if( strstr($m, 't_' ) ){
                $auxAr = explode( 't_', $m  );
                $M0 = $auxAr[1];}else $M0 = $m;
                $auxAr = explode('_',$M0);
                $M='';
                foreach ($auxAr as $value) 
                    $M.= ucfirst($value);
           //======== M End ===================
                
            
            if( in_array($m, $this->colNamesAr2)  )
			{   
				$k = array_search($m, $this->colNamesAr2);
				if($this->keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
                                if(!isset($myPk) )
                                    $myPk = $this->colNamesAr2[$k];
			}
			if($pk) {
                            $part4.= "\$tbl_pagesModel->__set('".$M."',\$formData['update_id'] );\r\n";
                            
                            
                            }  else {
                                $part4.= "\$tbl_pagesModel->__set('".$M."',\$formData['".$m."'] );\r\n";
                                
                                $part5.= "\$searchObj->getElement('".$m."')->setValue(\$formData['".$m."']);\r\n";
                                
                                $part6.= "
                     if(!empty(\$formData['".$m."']) )
                    \$a = \$a -> where('".$m." = ?', \$formData['".$m."'] ) ;\r\n";
                            }
        }
        
       $this->indexAction .= $part2.$part3.$part4; 
       
       $auxAr = explode("/*part_4*/", $this->sampleFile);
        
        $auxAr[1] = str_replace('t_evaluator_id',$myPk, $auxAr[1] );
        $between = str_replace('Evaluator',$pdoTable, $auxAr[1] );
        $between = str_replace('evaluator',  strtolower($pdoTable), $auxAr[1] );
        
        
        $this->indexAction .= $between;
        $this->indexAction .= $part5;
        
        
        $auxAr = explode("/*part_5*/", $this->sampleFile);
        
        $between = str_replace('t_evaluator_id',$myPk, $auxAr[1] );
        $between = str_replace('Evaluator',$pdoTable, $between );
        $between = str_replace('evaluator',  strtolower($pdoTable), $between );
        
       
        $this->indexAction .= $between;
        $this->indexAction .= $part6;
        
        $auxAr = explode("/*part_6*/", $this->sampleFile);
        
        $auxAr[1] = str_replace('t_evaluator_id',$myPk, $auxAr[1] );
        $endPart = str_replace('Evaluator',$pdoTable, $auxAr[1] );
        $endPart = str_replace('evaluator',  strtolower($pdoTable), $auxAr[1] );
        
        $this->indexAction .= $endPart;
        
        $this->indexAction = "public function indexAction(){".$this->indexAction."}";
        
    }
    
    public function generateRequestpagesAction(){
     
      $pdoTable = ucfirst( ltrim($this->table,'tbl_') );
        
        
        $j = -1; $part7to8 = ''; $part9to10 = ''; $firstNonPkField = NULL; 
        foreach ($this->colNamesAr1 as $m){
            $j++;
	    $pk = false;
           
            
            if( in_array($m, $this->colNamesAr2)  )
			{   
				$k = array_search($m, $this->colNamesAr2);
				if($this->keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
                                if(!isset($myPk) )
                                    $myPk = $this->colNamesAr2[$k];
			}
			if($pk) {
                            $o=null;
                            
                            } else {
                                $part7to8 .= "\$row['".$m."'][\$i] = \$R['".$m."'];\r\n";
                                if($j > 1)
                                    $part9to10 .= "<td>\".\$row['".$m."'][\$i].\"</td>\r\n";
                                
                                if(empty($firstNonPkField)){
                                    $firstNonPkField = $m;
                                    $part8to9 = "<td>\".\$row['".$m."'][\$i].\"<br>\r\n";
                                }
                                
                                
                            }
        }
        
        $auxAr = explode("/*part_7*/", $this->sampleFile);
        $part7 = $auxAr[1];
        $part7 = str_replace('t_evaluator_id',$myPk, $part7 );
        $part7 = str_replace('Evaluator',$pdoTable, $part7 );
        $part7 = str_replace('evaluator',  strtolower($pdoTable), $part7 );
        
        $auxAr = explode("/*part_8*/", $this->sampleFile);
        $part8 = $auxAr[1];
        $part8 = str_replace('t_evaluator_id',$myPk, $part8 );
        $part8 = str_replace('Evaluator',$pdoTable, $part8 );
        $part8 = str_replace('evaluator',  strtolower($pdoTable), $part8 );
        
        $auxAr = explode("/*part_9*/", $this->sampleFile);
        $part9 = $auxAr[1];
        $part9 = str_replace('t_evaluator_id',$myPk, $part9 );
        $part9 = str_replace('Evaluator',$pdoTable, $part9 );
        $part9 = str_replace('evaluator',  strtolower($pdoTable), $part9 );
        
        $auxAr = explode("/*part_10*/", $this->sampleFile);
        $part10 = $auxAr[1];
        $part10 = str_replace('t_evaluator_id',$myPk, $part10 );
        $part10 = str_replace('Evaluator',$pdoTable, $part10 );
        $part10 = str_replace('evaluator',  strtolower($pdoTable), $part10 );
        
        $this->requestpagesAction = $part7.$part7to8.$part8.$part8to9.$part9.$part9to10.$part10;
      
    }
    
    public function generateRequestupdateAction(){
        $pdoTable = ucfirst( ltrim($this->table,'tbl_') );
        
        
        $j = -1; $part11to12 = ''; 
        foreach ($this->colNamesAr1 as $m){
            $j++;
	    $pk = false;
            
            
            if( in_array($m, $this->colNamesAr2)  )
			{   
				$k = array_search($m, $this->colNamesAr2);
				if($this->keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
                                if(!isset($myPk) )
                                    $myPk = $this->colNamesAr2[$k];
			}
			if($pk) {
                            
                             $o=null;
                            } else {
                                
                              $part11to12 .= "\$form->".$m."->setValue(\$rowset[0]['".$m."']);\r\n"; 
                                
                                
                            }
        }
        
        $auxAr = explode("/*part_11*/", $this->sampleFile);
        $part11 = $auxAr[1];
        $part11 = str_replace('t_evaluator_id',$myPk, $part11 );
        $part11 = str_replace('Evaluator',$pdoTable, $part11 );
        $part11 = str_replace('evaluator',  strtolower($pdoTable), $part11 );
        
        $auxAr = explode("/*part_12*/", $this->sampleFile);
        $part12 = $auxAr[1];
        $part12 = str_replace('t_evaluator_id',$myPk, $part12 );
        $part12 = str_replace('Evaluator',$pdoTable, $part12 );
        $part12 = str_replace('evaluator',  strtolower($pdoTable), $part12 );
        
        $this->requestupdateAction = $part11.$part11to12.$part12;
    }
}