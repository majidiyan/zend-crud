<?php
/*part_1*/
class Admin_Form_Addexams extends Zend_Form
{

    public function init()
    {
 
		
        $this->setMethod('POST');
        $this->setAction('');
        $this->setName('addexams');
        $this->setEnctype('multipart/form-data');

        $update_id = new Zend_Form_Element_Hidden('update_id');
/*part_1*/
/*part_2*/
        $examName = new Zend_Form_Element_Text('t_exam_name');
        $examName->setAttrib('class','form-control');

        $examCode = new Zend_Form_Element_Text('t_exam_code');
        $examCode->setAttrib('class','form-control');
/*part_2*/
        

        



/*part_3*/
        $this->setDecorators(
            array(
                array('ViewScript', array('viewScript' => 'form-layout/add_exams.phtml'))
            )
        );

        $this->addElements(array($update_id, $examName, $examCode));
        $this->setElementDecorators(array('ViewHelper'));

    }


}

