<?php

class Admin_Model_Pages
{

	// PROTECTED VARS STORE ACTUAL DATA - GET/SET ONLY EXPOSED THROUGH METHODS
/*part_1*/
	protected $_id;
	protected $_first_name;
	protected $_title;
	protected $_content;
	protected $_parent_id;
	protected $_link;
	protected $_is_active;
	protected $_sort_id;
/*part_1*/

 	// CONSTRUCTOR ALLOWS FOR SETTING OF ALL PROPS
    public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }
 
 	// DEFAULT SETTER
    public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid maillist property');
        }
        $this->$method($value);
    }
 
 	// DEFAULT GETTER
    public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid page property');
        }
        return $this->$method();
    }
    
 	// FUNCTION TO ALLOW FOR SETTING PROPERTIES FROM ARRAY
    public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
    
    // ALL THE GETTERS AND SETTERS
/*part_2*/    
    public function setId($id)
    {
    	$this->_id = (int) $id;
    }
    
    public function getId()
    {
    	return $this->_id;
    }
    
    public function setTitle($text)
    {
    	$this->_title = (string) $text;
    }
    
    public function getTitle()
    {
    	return $this->_title;
    }
    
    public function setContent($text)
    {
    	$this->_content = (string) $text;
    }
    
    public function getContent()
    {
    	return $this->_content;
    }
    
    public function setParent_id($intiger)
    {
    	$this->_parent_id = (int) $intiger;
    }
    
    public function getParent_id()
    {
    	return $this->_parent_id;
    }
    
    public function setLink($text)
    {
    	$this->_link = (string) $text;
    }
    
    public function getLink()
    {
    	return $this->_link;
    }
    
    public function setIs_active($intiger)
    {
    	$this->_is_active = (int) $intiger;
    }
    
    public function getIs_active()
    {
    	return $this->_is_active;
    }
    
    public function setSort_id($intiger)
    {
    	$this->_sort_id = (int) $intiger;
    }
    
    public function getSort_id()
    {
    	return $this->_sort_id;
    }
/*part_2*/

}
