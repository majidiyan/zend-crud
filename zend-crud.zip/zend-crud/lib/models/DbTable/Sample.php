<?php

class Admin_Model_DbTable_Pages extends Zend_Db_Table_Abstract
{
/*part_1*/
    protected $_name = 'tbl_pages';
/*part_1*/

}

