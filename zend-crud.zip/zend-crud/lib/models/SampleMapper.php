<?php

class Admin_Model_PagesMapper
{

	// SAVE THE TABLE IN PRIVATE VAR
    protected $_dbTable;
 
 	// GETTER/SETTER FOR TABLE
    public function setDbTable($dbTable)
    {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception('Invalid table data gateway provided');
        }
        $this->_dbTable = $dbTable;
        return $this;
    }
 
    public function getDbTable()
    {
        if (null === $this->_dbTable) {
          /*part_1*/$this->setDbTable('Admin_Model_DbTable_Pages');/*part_1*/
        }
        return $this->_dbTable;
    }
 
 	// SAVE() METHOD TO SAVE TO DB
/*part_2*/ 
   public function save(Admin_Model_Pages $maillist) /*part_2*/
    {
		
	/*part_3*/	
        $data = array(
            'title' => $maillist->getTitle(),
            'content' => $clean_content,
            'parent_id'   => $maillist->getParent_id(),
            'link' => $maillist->getLink(),
            'is_active' => $maillist->getIs_active(),
            'sort_id' => $maillist->getSort_id()
        );/*part_3*/
/*part_4*/
        if ( !( ($id = $maillist->getId()) > 0)  ) {
            unset($data['id']);
            $this->getDbTable()->insert($data);
        } else {
            $this->getDbTable()->update($data, array('id = ?' => $id));
        }
/*part_4*/
    }//save
/*part_5*/	
	public function del(Admin_Model_Pages $maillist)
	{
		$id = $maillist->getId();
		$this->getDbTable()->delete( array('id = ?' => $id));
	}//del
/*part_5*/    
    // TO-DO: IMPLEMENT find() method to get one object by id
    
    // TO-DO: IMPLEMENT fetchAll method to get all records


}
