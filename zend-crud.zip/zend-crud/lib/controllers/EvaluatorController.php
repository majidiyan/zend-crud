<?php
/*part_1*/
class Admin_EvaluatorController extends Zend_Controller_Action
{
/*part_1*/


    public function indexAction(){
/*part_2*/     
        $AddpagesForm = new Admin_Form_Addevaluator();
        
        $this->view->form = $AddpagesForm;
        $this->view->searchUsed = false;

        
        $tbl_pages = new Admin_Model_DbTable_Evaluator();
        $myRowSet = $tbl_pages->fetchAll();

        $this->view->tbl_pages = $myRowSet;

        $tbl_pagesMapper = new Admin_Model_EvaluatorMapper();
        $tbl_pagesModel = new Admin_Model_Evaluator();


        $this->view->searchForm = new Admin_Form_Searchevaluator();
/*part_2*/ 

/*part_3*/
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();



            if(!isset($formData['search_please']) )

                if($formData['del_id'] > 0){


                    $tbl_pagesModel->__set('EvaluatorId',$formData['del_id'] );

                    $tbl_pagesMapper->del($tbl_pagesModel);
                }else{
/*part_3*/
                    
                    $tbl_pagesModel->__set('EvaluatorId',$formData['update_id'] );
                    $tbl_pagesModel->__set('EvaluatorFname',$formData['t_evaluator_fname'] );
                    $tbl_pagesModel->__set('EvaluatorLname',$formData['t_evaluator_lname'] );
                    $tbl_pagesModel->__set('EvaluatorEmail',$formData['t_evaluator_email'] );
                    $tbl_pagesModel->__set('EvaluatorMobile',$formData['t_evaluator_mobile'] );
                    $tbl_pagesModel->__set('EvaluatorUser',$formData['t_evaluator_user'] );
                    $tbl_pagesModel->__set('EvaluatorPass',$formData['t_evaluator_pass'] );

/*part_4*/
                    $tbl_pagesMapper->save($tbl_pagesModel);

                    $this->view->messages = '<span class="msg-success">! <span>'.'صفحه با موفقیت ثبت شد'.'</span>
                    		</span>';
                } else {

               
                $searchObj = new Admin_Form_Searchevaluator();
/*part_4*/ 
                $searchObj->getElement('t_evaluator_fname')->setValue($formData['t_evaluator_fname']);
                $searchObj->getElement('t_evaluator_lname')->setValue($formData['t_evaluator_lname']);
                $searchObj->getElement('t_evaluator_email')->setValue($formData['t_evaluator_email']);
                $searchObj->getElement('t_evaluator_mobile')->setValue($formData['t_evaluator_mobile']);
                $searchObj->getElement('t_evaluator_user')->setValue($formData['t_evaluator_user']);
/*part_5*/
                $this->view->searchForm = $searchObj;
               

                $obj = new Admin_Model_DbTable_Evaluator();




                $a = $obj->select();
/*part_5*/
                if(!empty($formData['t_evaluator_fname']) )
                    $a = $a -> where('t_evaluator_fname = ?', $formData['t_evaluator_fname'] ) ;
                if(!empty($formData['t_evaluator_lname']) )
                    $a = $a -> where('t_evaluator_lname LIKE ?', "%".$formData['t_evaluator_lname']."%" ) ;
                if(!empty($formData['t_evaluator_email']) )
                    $a = $a -> where('t_evaluator_email LIKE ?', "%".$formData['t_evaluator_email']."%" ) ;
                if(!empty($formData['t_evaluator_user']) )
                    $a = $a -> where('t_evaluator_user LIKE ?', "%".$formData['t_evaluator_user']."%" ) ;

/*part_6*/
                $rowset = $obj->fetchAll($a);

                $ids=array();
                foreach($rowset as $m)
                    $ids[]=$m->t_evaluator_id;

                $this->view->searchIds = $ids;
                $this->view->searchUsed = true;
            }



        }//POST
/*part_6*/       
    }
    
/*part_7*/
    public function requestpagesAction()
    {
        
        $request = $this->getRequest()->getPost();

       
       
        $startEvaluator = $request['data'];
        $evaluatorNow = $request['name'];
        $strID = $request['choose'];
        $strIDs = explode("_",$strID);

        
        $this->_helper->getHelper('layout')->disableLayout();



        $Paper=10; //تعداد کاربران نمایش داده شده در هر صفحه
        $accessPages=10;//تعداد صفحاتی که بصورت پیوند ظاهر می شوند
        $row=array();
        $tbl_pages = new Admin_Model_DbTable_Evaluator();

        $rowset = $tbl_pages->fetchAll($tbl_pages->select()
            ->where('t_evaluator_id IN (?)', $strIDs)
            
        ); $num=count($rowset);


        $numRowWanted=($evaluatorNow-1)*$Paper;




        for($i=1;$i<=$Paper;$i++){

            if($i > ($num - $numRowWanted ) )break;
            $rowset->seek($numRowWanted+$i-1);

            $R = $rowset->current();
            $row['t_evaluator_id'][$i] = $R['t_evaluator_id'];
/*part_7*/
            $row['t_evaluator_fname'][$i] = $R['t_evaluator_fname'];
            $row['t_evaluator_lname'][$i] = $R['t_evaluator_lname'];
            $row['t_evaluator_email'][$i] = $R['t_evaluator_email'];
            $row['t_evaluator_user'][$i] = $R['t_evaluator_user'];
            $row['t_evaluator_mobile'][$i] = $R['t_evaluator_mobile'];
/*part_8*/

        }
        $output="";
        if($num != 0)
            for($i=1;$i<=$Paper;$i++){
                if( !($row['t_evaluator_id'][$i] >= 1)) break;


                $aaa = $this->view->homeUrl();
                $mmyAr = explode('/admin',$aaa);

                $output.="<tr>
            <td>".$row['t_evaluator_id'][$i]."</td>
/*part_8*/
            <td>".$row['t_evaluator_fname'][$i]."<br>
/*part_9*/
            <span class=\"text-sm\">
             <a href=\"#editUser\" data-toggle=\"modal\" class=\"padding-right-small\"
              onclick=\"formUpdate('".$row['t_evaluator_id'][$i]."')\"><i class=\"fa fa-pencil \"></i> ویرایش</a>
              <a href=\"#myModal\" data-toggle=\"modal\" onclick=\"f2('".$row['t_evaluator_id'][$i]."')\">
              <i class=\"fa fa-trash-o \"></i> حذف</a></span></td>
/*part_9*/
              <td>".$row['t_evaluator_lname'][$i]."</td>
              <td>".$row['t_evaluator_user'][$i]."</td>
              <td>".$row['t_evaluator_email'][$i]."</td>
              <td>".$row['t_evaluator_mobile'][$i]."</td>
/*part_10*/
          </tr>";

            }//i

        if(floor($num/$Paper) < ($num/$Paper))
            $numPagesTotal=floor($num/$Paper)+1;//تعداد کل صفحات
        else $numPagesTotal=floor($num/$Paper);
        $extra=$strID;
        $aux2 = $this->_helper->pager($startEvaluator,$accessPages,$evaluatorNow,$numPagesTotal,$extra);


        $this->view->aliAli2 = $output."~".$aux2;



    }//=================================================== requestpagesAction =================================================
/*part_10*/

/*part_11*/
    public function requestupdateAction()
    {
        $request = $this->getRequest()->getPost();
        $id = $request['id'];

        $this->_helper->getHelper('layout')->disableLayout();
       $tbl_pages = new Admin_Model_DbTable_Evaluator();
        $rowset = $tbl_pages->fetchAll($tbl_pages->select()->where('t_evaluator_id = ? ', $id) );
        $form = new Admin_Form_Addevaluator();
/*part_11*/


        $form->t_evaluator_fname->setValue($rowset[0]['t_evaluator_fname']);
        $form->t_evaluator_lname->setValue($rowset[0]['t_evaluator_lname']);
        $form->t_evaluator_mobile->setValue($rowset[0]['t_evaluator_mobile']);
        $form->t_evaluator_email->setValue($rowset[0]['t_evaluator_email']);
        $form->t_evaluator_user->setValue($rowset[0]['t_evaluator_user']);


/*part_12*/

        $form->update_id->setValue($id);

        $this->view->form = $form;
    }//===============================================   requestupdate    =================================================
/*part_12*/

}
?>
