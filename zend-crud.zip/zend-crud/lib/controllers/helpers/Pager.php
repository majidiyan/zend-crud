<?php
/**
 * Created by PhpStorm.
 * User: ali
 * Date: 10/13/15
 * Time: 10:44 PM
 */
class Admin_Controller_Action_Helper_Pager extends Zend_Controller_Action_Helper_Abstract
{
    function direct($stp,$length,$wanted,$numPagesTotal,$extra){

        $strMy=" ";

        if($wanted < $stp) $stp--;
        elseif($wanted > ($stp+$length-1)) $stp++;

        if($stp > 1){
            $goback = $stp-1;
            for($jump=0;$jump<10;$jump++){
                if( ($stp -$jump ) > 0 )
                    $goback = $stp -$jump;
                else break;
            }//jump
            $strMy.="<li><a  onclick=\"getData($goback + 1, $goback ,'".$extra."')\"> &laquo; </a></li>";
        }//if
        $aux=$stp+$length-1;
        if($aux>$numPagesTotal) $aux=$numPagesTotal;
        for($i=$stp;$i<=$aux;$i++)
        {
            if($i == $wanted)
                $strMy.="<li class=\"active\"><a  onclick=\"getData($stp,$i,'".$extra."')\" >".$i."</a></li>";
            else
                $strMy.="<li><a  onclick=\"getData($stp,$i,'".$extra."')\">".$i."</a></li>";
        }//i
        if(($stp+$length-1) < $numPagesTotal){
            $goahead = $length+$stp;
            for($jump=0;$jump<10;$jump++){
                if( ($jump+$length+$stp) < $numPagesTotal )
                    $goahead = $jump+$length+$stp;
                else break;
            }//jump
            $strMy.="<li><a  onclick=\"getData($stp+$jump, $goahead ,'".$extra."')\"> &raquo; </a></li>";
        }//if

        return $strMy;


    }
}