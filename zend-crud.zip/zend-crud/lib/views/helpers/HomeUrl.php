<?php
/**
 * Created by PhpStorm.
 * User: ali
 * Date: 10/12/15
 * Time: 6:01 PM
 */
class Admin_View_Helper_HomeUrl extends Zend_View_Helper_Abstract
{
    public function homeUrl()
    {
        $html = sprintf(
            "%s://%s%s",
            isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
            $_SERVER['SERVER_NAME'],
            $_SERVER['REQUEST_URI']
        );

        $auxAr = explode('admin',$html);
        $result = $auxAr[0].'admin';
// some logic that fills in $html.
        return $result;
    }
}