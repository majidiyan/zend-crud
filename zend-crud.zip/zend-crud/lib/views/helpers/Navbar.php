<?php
/**
 * Created by PhpStorm.
 * User: ali
 * Date: 10/12/15
 * Time: 6:01 PM
 */
class Admin_View_Helper_Navbar extends Zend_View_Helper_Abstract
{
    public function navbar()
    {
        $outPutAr = array();

        $adminObj = new Admin_Model_DbTable_Login();
        $row = $adminObj->fetchRow($adminObj->select()->where('username=?', $_COOKIE['admin_username'])
                                                      ->where('password=?',md5(md5($_COOKIE['admin_password'])) )   );



        $outPutAr['adminFullname'] = $row['fullname'];
        return $outPutAr;
    }
}