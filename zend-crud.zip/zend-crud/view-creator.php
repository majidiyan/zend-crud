<?php
class viewCreator{
    private $table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2 ;
    
    private $classController, $indexAction, $requestpagesAction, $requestupdateAction;
    
    private $sampleFile1, $sampleFile2, $sampleFile3;
    
    function __construct($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
        $this->table = $table;
        $this->colNamesAr1 = $colNamesAr1;
        $this->colTypesAr1 = $colTypesAr1;
        $this->colNamesAr2 = $colNamesAr2;
        $this->keyNamesAr2 = $keyNamesAr2;
        $this->isUniqueAr2 = $isUniqueAr2; 
        
        $this->sampleFile1 = '';
        $fp = fopen("lib/views/scripts/sample-requestupdate.txt","r");
            for($i = 1; $i <= 3; $i++)
                $this->sampleFile1 = $this->sampleFile1.fgets($fp,2000);
        fclose($fp);
        
        $this->sampleFile2 = '';
        $fp = fopen("lib/views/scripts/sample-requestpages.txt","r");
            for($i = 1; $i <= 57; $i++)
                $this->sampleFile2 = $this->sampleFile2.fgets($fp,2000);
        fclose($fp);
        
         $this->sampleFile3 = '';
        $fp = fopen("lib/views/scripts/sample-index.txt","r");
            for($i = 1; $i <= 200; $i++)
                $this->sampleFile3 = $this->sampleFile3.fgets($fp,2000);
        fclose($fp);
    }
    
    public function requestUpdateCreator(){
        $pdoTableLower =  strtolower(ltrim($this->table,'tbl_') ) ;
        
        if(!$c = opendir('output/views/scripts/'.$pdoTableLower) )
			mkdir('output/views/scripts/'.$pdoTableLower);
        
         $fp = fopen( "output/views/scripts/$pdoTableLower/requestupdate.phtml","w+");
		fwrite($fp, $this->sampleFile1);
		fclose($fp);
        
    }
    
    public function requestpagesCreator(){
        $auxAr = explode('/*part_1*/', $this->sampleFile2);
        $part1 = $auxAr[1];
        
        $part2=''; 
        $i = -1;
        foreach ($this->colNamesAr1 as $m){
             $i++;
            if($i == 0) continue;
            $part2.= "<th>  ".$m." </th> \r\n";
           
        }
        
        
         $auxAr = explode('/*part_2*/', $this->sampleFile2);
        $part3 = $auxAr[1];
        
        $output = $part1.$part2.$part3;
        
        $pdoTableLower =  strtolower(ltrim($this->table,'tbl_') ) ;
        
        if(!$c = opendir('output/views/scripts/'.$pdoTableLower) )
			mkdir('output/views/scripts/'.$pdoTableLower);
        
         $fp = fopen( "output/views/scripts/$pdoTableLower/requestpages.phtml","w+");
		fwrite($fp, $output );
		fclose($fp);
        
        
    }
    
    public function indexCreator(){
        
        $pdoTable = ucfirst( ltrim($this->table,'tbl_') );
        $pdoTableLower =  strtolower(ltrim($this->table,'tbl_') ) ;
        
        $auxAr = explode('/*part_1*/', $this->sampleFile3);
        $part1 = $auxAr[1];
        
        $auxAr = explode('/*part_2*/', $this->sampleFile3);
        $part2 = $auxAr[1];
        
        $part1 = str_replace('Evaluator', $pdoTable, $part1 );
        $part1 = str_replace('evaluator', $pdoTableLower, $part1 );
        
        $part2 = str_replace('Evaluator', $pdoTable, $part2 );
        $part2 = str_replace('evaluator', $pdoTableLower, $part2 );
        
        
        $partMid = '';
        
        foreach ($this->colNamesAr1 as $m){
            
	    $pk = false;
           
            
            if( in_array($m, $this->colNamesAr2)  )
			{   
				$k = array_search($m, $this->colNamesAr2);
				if($this->keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
			}
	   if(!$pk) 
                 $partMid .= "document.getElementById('".$m."').value=''; \r\n ";       
                            
                      
        }
        
        $partMid = str_replace('Evaluator', $pdoTable, $partMid );
        $partMid = str_replace('evaluator', $pdoTableLower, $partMid );
        
        
        $output = $part1.$partMid.$part2;
        
        
        
        
        
        if(!$c = opendir('output/views/scripts/'.$pdoTableLower) )
			mkdir('output/views/scripts/'.$pdoTableLower);
        
         $fp = fopen( "output/views/scripts/$pdoTableLower/index.phtml","w+");
		fwrite($fp, $output );
		fclose($fp);
        
    }
    
    
}//viewCreator