<?php
require_once 'mysql-connect.php';

class sqlStruct extends mysqlConnect{
	
	function __construct(){
		parent::__construct();
	}
	
	public function listTables(){
		
		$tableAr = array();
		$dbname = $this->dbName; 
		$result = mysql_query("SHOW TABLES FROM $dbname",$this->conn);
		$numTables = mysql_num_rows($result);
		
		for($i=1; $i<=$numTables;$i++){
			$row = mysql_fetch_row($result);
			$tableAr[] = $row[0];
		}//i
		return $tableAr; 
		
	}
	
	public function listTableColNames($tableName){
		$fieldsAr = array();
		
		$sql2 = "SHOW COLUMNS FROM ".$tableName." ";
		$result2 = mysql_query($sql2,$this->conn);
		$n2 = mysql_num_rows($result2);
		
		for($j=1; $j<=$n2; $j++){
			$row2=mysql_fetch_array($result2,$this->conn);
			$fieldsAr[] = $row2['Field'];
		}//j
		return $fieldsAr;	
	}
	
	public function listTableColTypes($tableName){
		$typeAr = array();
	
		$sql2 = "SHOW COLUMNS FROM ".$tableName." ";
		$result2 = mysql_query($sql2,$this->conn);
		$n2 = mysql_num_rows($result2);
	
		for($j=1; $j<=$n2; $j++){
			$row2=mysql_fetch_array($result2,$this->conn);
			$typeAr[] = $row2['Type'];
		}//j
		return $typeAr;
	}
	public function tableIndex($table,$col){
		$sql2 = "SHOW KEYS FROM ".$table." ";
		$result2 = mysql_query($sql2,$this->conn);
		$n2 = mysql_num_rows($result2);
		$indexAr = array('Key_name'=>'','Non_unique'=>'');
		
		for($j=1; $j<=$n2; $j++){
			$row2=mysql_fetch_array($result2);
			if($col == $row2['Column_name']){
				$indexAr = array('Key_name'=>$row2['Key_name'],'Non_unique'=>$row2['Non_unique']);
				break;
			}
		}//j
		return $indexAr;
	}
	
}