<?php
class filesAndDirStructClass{
	
	public function repareStructOutput(){
	// directories
		if(!$c = opendir('output'))
			mkdir("output");
		
		if(!$c = opendir('output/models'))
			mkdir("output/models");
		
		if(!$c = opendir('output/models/DbTable'))
			mkdir("output/models/DbTable");
		
		if(!$c = opendir('output/controllers'))
			mkdir("output/controllers");
		
		if(!$c = opendir('output/controllers/helpers'))
			mkdir("output/controllers/helpers");
		
		if(!$c = opendir('output/forms'))
			mkdir("output/forms");
		
		if(!$c = opendir('output/layouts'))
			mkdir("output/layouts");
		
		if(!$c = opendir('output/layouts/scripts'))
			mkdir("output/layouts/scripts");
		
		if(!$c = opendir('output/views'))
			mkdir("output/views");
		
		if(!$c = opendir('output/views/filters'))
			mkdir("output/views/filters");
		
		if(!$c = opendir('output/views/helpers'))
			mkdir("output/views/helpers");
		
		if(!$c = opendir('output/views/scripts'))
			mkdir("output/views/scripts");
		
		if(!$c = opendir('output/views/scripts/form-layout'))
			mkdir("output/views/scripts/form-layout");
		
	//----------------- files
	
		if(!file_exists('output/views/helpers/HomeUrl.php'))
			copy('lib/views/helpers/HomeUrl.php', 'output/views/helpers/HomeUrl.php');
		
		if(!file_exists('output/views/helpers/Navbar.php'))
			copy('lib/views/helpers/Navbar.php', 'output/views/helpers/Navbar.php');
		
		if(!file_exists('output/controllers/helpers/Pager.php'))
			copy('lib/controllers/helpers/Pager.php', 'output/controllers/helpers/Pager.php');
		
		
	}
}