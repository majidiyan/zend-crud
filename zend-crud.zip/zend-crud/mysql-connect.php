<?php
class mysqlConnect{
	protected $conn,$db;
	
	private $host = 'localhost';
	private $username = 'root';
	private $password = 'mob09363447457';
	protected $dbName = 'hrm';
	
	function __construct(){
		$host = $this->host;
		$username = $this->username;
		$password = $this->password;
		$dbName = $this->dbName;
		
		$this->conn = mysql_connect($host,$username,$password);
		$this->db = mysql_select_db($dbName,$this->conn);
		
		
	}
	
	
}