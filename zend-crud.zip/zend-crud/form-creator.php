<?php
class formCreator{
	
	private function formElementObjName($colName)
	{
		$aux = explode('_', $colName);
		$str = '';
		$j = 0;
		foreach ($aux as $m){
			$j++;
			if( strlen($m) == 1 && $j == 1)
				continue;
			$str.= ucfirst($m);
		}
		$str[0] = strtolower($str[0]);
		return $str;
	}
	
	private function enumTypeToArray($enumType){
		$aux = ltrim($enumType,'enum(');
		$aux = rtrim($aux,')');
		$auxAr = explode(',', $aux);
		$a = array();
		foreach($auxAr as $m){
			$a[] = trim($m,"'");
		}
		
		return $a;
	}
	
	public function generateForm($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		$fp = fopen("lib/forms/Sample.txt","r");
		$str = '';
		for($i = 1; $i <= 44; $i++)
			$str = $str.fgets($fp,2000);
		fclose($fp);
		
		$auxAr = explode("/*part_1*/",$str);
		$auxAr[1] = str_replace("exams", strtolower($pdoTable), $auxAr[1]);
		$str = implode('',$auxAr);
		
		$part2 = ''; $subPart3 = "array(\$update_id, ";
		$j = -1; 
		foreach ($colNamesAr1 as $m)
		{
			$j++;
			$pk = false;
			if( in_array($m, $colNamesAr2)  )
			{   
				$k = array_search($m, $colNamesAr2);
				if($keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
			}
			if($pk) continue;
			
			if( strstr(strval($colTypesAr1[$j]) ,'int') ){
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]) ,'varchar') ){
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]),'text' ) ){
			
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]),'enum' ) ){
			$enumStr = '';
			$enumAr = $this->enumTypeToArray($colTypesAr1[$j]);
			
			foreach ($enumAr as $enumVar)
				$enumStr.= "'".$enumVar."'=>'".$enumVar.": [".$enumVar."]',";
			
			$enumStr = substr_replace($enumStr, "", -1);
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Radio('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setMultiOptions(array(".$enumStr."))
        		->setAttrib('class','radio-inline')
        		->setSeparator('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
						";
				
			}
			
			$subPart3.= "\$".$this->formElementObjName($m)." ,";
			
		}//All Fields ($m)
		
		$subPart3 = substr_replace($subPart3, "", -1).')';
		
		$part3 = "
				\$this->setDecorators(
            array(
                array('ViewScript', array('viewScript' => 'form-layout/add_".strtolower($pdoTable).".phtml'))
            )
        );

        \$this->addElements(".$subPart3.");
        \$this->setElementDecorators(array('ViewHelper'));

    }


}
				";
		
		$auxAr = explode("/*part_2*/",$str);		
		$str = $auxAr[0].$part2.$auxAr[2];
		
		$auxAr = explode("/*part_3*/",$str);
		$str = $auxAr[0].$part3.$auxAr[2];
		
		 $fp = fopen( "output/forms/Add".strtolower($pdoTable).".php","w+");
		fwrite($fp, $str);
		fclose($fp); 
		
	}
	
	public function generateFormLayout($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		
		$part1 = '
<form action="<?php echo $this->element->getAction(); ?>" name="add'.strtolower($pdoTable).'" method="<?php echo $this->element->getMethod(); ?>"  enctype="<?php echo $this->element->getEnctype(); ?>">
				';
		$updateElementPart = array('<?php echo $this->element->update_id; ?>');
		$part2='';
		
		$j = -1;
		foreach ($colNamesAr1 as $m)
		{
			
			$pk = false;
			if( in_array($m, $colNamesAr2)  )
			{
				$k = array_search($m, $colNamesAr2);
				if($keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
			}
			if($pk) continue;
			
			$j++;
			$part2.= '
					<tr>
           <td><div class="form-group">
					'.$updateElementPart[$j].'
                   <label>
                       '.$m.'
                   </label>
               </div></td>
           <td><div class="form-group">
                   <?php echo $this->element->'.$m.'; ?>
               </div></td>
       </tr>
					';
		}
		
		$output = $part1.'<table>'.$part2.'</table></form>';
		
		$fp = fopen( "output/views/scripts/form-layout/add_".strtolower($pdoTable).".phtml","w+");
		fwrite($fp, $output);
		fclose($fp);
		
	}
	
	public function generateSearchForm($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		$fp = fopen("lib/forms/SampleSearch.txt","r");
		$str = '';
		for($i = 1; $i <= 59; $i++)
			$str = $str.fgets($fp,2000);
		fclose($fp);
		
		$auxAr = explode("/*part_1*/",$str);
		$auxAr[1] = str_replace("page", strtolower($pdoTable), $auxAr[1]);
		$str = implode('',$auxAr);
		
		$part2 = ''; $subPart3 = "array(\$search_id, ";
		$j = -1;
		foreach ($colNamesAr1 as $m)
		{
			$j++;
			$pk = false;
			if( in_array($m, $colNamesAr2)  )
			{
				$k = array_search($m, $colNamesAr2);
				if($keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
			}
			if($pk) continue;
			
		if( strstr(strval($colTypesAr1[$j]) ,'int') ){
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control')->setLabel('".$m."'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]) ,'varchar') ){
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control')->setLabel('".$m."'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]),'text' ) ){
			
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Text('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setAttrib('class','form-control')->setLabel('".$m."'); \r\n
						";
				
			}elseif( strstr(strval($colTypesAr1[$j]),'enum' ) ){
			$enumStr = '';
			$enumAr = $this->enumTypeToArray($colTypesAr1[$j]);
			
			foreach ($enumAr as $enumVar)
				$enumStr.= "'".$enumVar."'=>'".$enumVar.": [".$enumVar."]',";
			
			$enumStr = substr_replace($enumStr, "", -1);
				
				$part2.="
		\$".$this->formElementObjName($m)." = new Zend_Form_Element_Radio('".$m."'); \r\n
        \$".$this->formElementObjName($m)."->setMultiOptions(array(".$enumStr."))
        		->setAttrib('class','radio-inline')
                        ->setLabel('".$m."')
        		->setSeparator('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
						";
				
			}
			
			$subPart3.= "\$".$this->formElementObjName($m)." ,";
			
		}//foreach ($m)
			
		$subPart3 = $subPart3." \$submitBtn )";
		
		$part3 = "
				\$submitBtn = new Zend_Form_Element_Submit('submit');
        \$submitBtn->setLabel('جستجو');

        \$this->addElements(".$subPart3." ); 

    }

}
				";
		
		$auxAr = explode("/*part_2*/",$str);
		$str = $auxAr[0].$part2.$auxAr[2];
		
		$auxAr = explode("/*part_3*/",$str);
		$str = $auxAr[0].$part3.$auxAr[2];
		
		$fp = fopen( "output/forms/Search".strtolower($pdoTable).".php","w+");
		fwrite($fp, $str);
		fclose($fp);
		
	}
}