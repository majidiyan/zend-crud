<?php
class Task {
    public $tables = array(
        't_motion'
    );
}
