<!DOCTYPE html>
<html>
    <head>
        <title>page title</title>
        <meta charset="UTF-8" />  
        <?php
        function showFn($ar1, $ar2, $ar3, $ar4, $ar5, $ar6){
            print_r($ar1);
            echo "<br> .......................................................<br>";
            
            print_r($ar2);
            echo "<br> .......................................................<br>";
            
            print_r($ar3);
            echo "<br> .......................................................<br>";
            
            print_r($ar4);
            echo "<br> .......................................................<br>";
            
            print_r($ar5);
            echo "<br> .......................................................<br>";
            
            print_r($ar6);
            
            echo "<br><br><br>";
        }
        ?>
    </head>
    <body>
<?php
require 'config.php';
require 'task.php';
require 'files-and-dir-struct-class.php';

require 'model-creator.php';       // (M)
require 'view-creator.php';        // (V)
require 'controller-creator.php';  // (C)
  
require 'form-creator.php';

$connParamObj = new config();
$taskObj = new Task();
$outputStructObj = new filesAndDirStructClass();


$table = array();
$colNamesAr1 = array(array());

$colTypesAr1 = array(array());
$colNamesAr2 = array(array());
$keyNamesAr2 = array(array());
$isUniqueAr2 = array(array());





$outputStructObj->repareStructOutput();


$conn = mysql_connect($connParamObj->myParams['host'],
        $connParamObj->myParams['user'],
        $connParamObj->myParams['pass']);

$dbname = $connParamObj->myParams['data'];
mysql_select_db($dbname);

$result = mysql_query("SHOW TABLES FROM $dbname");
$numTables = mysql_num_rows($result);


for($i=1; $i<=$numTables;$i++){
$row = mysql_fetch_row($result);
        $table[$i - 1] = $row[0];
	$sql2 = "SHOW COLUMNS FROM ".$row[0]." ";
	$result2 = mysql_query($sql2);
	$n2 = mysql_num_rows($result2);
	//check for id field name
			$row2=mysql_fetch_array($result2);
			$isId = ($row2['Field']=='id')?true:false;
			mysql_data_seek($result2, 0);			
	//check for id field name end
	
	$fieldsAr = array();
	for($j=1; $j<=$n2; $j++){
		$row2=mysql_fetch_array($result2);
			
	
                $colNamesAr1[$i - 1][$j - 1] = $row2['Field'];
                $colTypesAr1[$i - 1][$j - 1] = $row2['Type'];
        }//j	
}//i



mysql_data_seek($result, 0);

for($i=1; $i<=$numTables;$i++){
	$row = mysql_fetch_row($result);
	
	$sql2 = "SHOW KEYS FROM ".$row[0]." ";
	$result2 = mysql_query($sql2);
	$n2 = mysql_num_rows($result2);

	$row2=mysql_fetch_array($result2);
		
	mysql_data_seek($result2, 0);

	$fieldsAr = array();
	for($j=1; $j<=$n2; $j++){
		$row2=mysql_fetch_array($result2);
		
                $colNamesAr2[$i - 1][$j - 1] = $row2['Column_name'];
                $keyNamesAr2[$i - 1][$j - 1] = $row2['Key_name'];
                $isUniqueAr2[$i - 1][$j - 1] = $row2['Non_unique'];
	}//j


}//i


// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



for($i=1; $i<=$numTables;$i++){
    
    if( !in_array($table[$i-1], $taskObj->tables) )   continue;
    
    
    showFn($table[$i-1],
            $colNamesAr1[$i-1],
            $colTypesAr1[$i-1],
            $colNamesAr2[$i-1],
            $keyNamesAr2[$i-1],
            $isUniqueAr2[$i-1] );
  
  //                                                        Model
    if(isset($modelObj) )
        unset($modelObj);
    $modelObj = new modelCreator('');
    $modelObj->dbTable($table[$i-1]);
    $modelObj->model($table[$i-1],
                    $colNamesAr1[$i-1],
                    $colTypesAr1[$i-1],
                    $colNamesAr2[$i-1],
                    $keyNamesAr2[$i-1],
                    $isUniqueAr2[$i-1] );
    
    $modelObj->mapper($table[$i-1],
                        $colNamesAr1[$i-1],
                        $colTypesAr1[$i-1],
                        $colNamesAr2[$i-1],
                        $keyNamesAr2[$i-1],
                        $isUniqueAr2[$i-1] );
    
//                                                                  Controller
    
    if(isset($controllerObj) )
        unset($controllerObj);
    
    $controllerObj = new controllerCreator($table[$i-1],
                                            $colNamesAr1[$i-1],
                                            $colTypesAr1[$i-1],
                                            $colNamesAr2[$i-1],
                                            $keyNamesAr2[$i-1],
                                            $isUniqueAr2[$i-1] );
    
    $controllerStr = "<?php \r\n";
    $controllerObj->generateClassController();
    
    $controllerStr = $controllerStr.($controllerObj->classController)."\r\n";
    
    $controllerObj->generateIndexAction();
    $controllerStr = $controllerStr.($controllerObj->indexAction)."\r\n";
    
    $controllerObj->generateRequestpagesAction();
    $controllerStr = $controllerStr.($controllerObj->requestpagesAction)."\r\n";
    
    $controllerObj->generateRequestupdateAction();
    $controllerStr = $controllerStr.($controllerObj->requestupdateAction)."\r\n";
    
    
    $controllerStr = $controllerStr."}";
    
    $pdoTable = ucfirst( ltrim($table[$i-1],'t_') );
    
    
    $fp = fopen( "output/controllers/".$pdoTable."Controller.php","w+");
   fwrite($fp, $controllerStr);
   fclose($fp);
   
//                                                                      Forms
   if(isset($formObj) )
       unset($formObj);
   
    $formObj = new formCreator();
    $formObj->generateForm($table[$i - 1],
                            $colNamesAr1[$i - 1],
                            $colTypesAr1[$i - 1],
                            $colNamesAr2[$i - 1],
                            $keyNamesAr2[$i - 1],
                            $isUniqueAr2[$i - 1] );
    
    $formObj->generateSearchForm($table[$i - 1],
                                    $colNamesAr1[$i - 1],
                                    $colTypesAr1[$i - 1],
                                    $colNamesAr2[$i - 1],
                                    $keyNamesAr2[$i - 1],
                                    $isUniqueAr2[$i - 1] );
    
    $formObj->generateFormLayout($table[$i - 1],
                                    $colNamesAr1[$i - 1],
                                    $colTypesAr1[$i - 1],
                                    $colNamesAr2[$i - 1],
                                    $keyNamesAr2[$i - 1],
                                    $isUniqueAr2[$i - 1] );
    
//                                                                  Views
 
    if(isset($viewObj) )
        unset($viewObj);
    
$viewObj = new viewCreator($table[$i - 1],
                            $colNamesAr1[$i - 1],
                            $colTypesAr1[$i - 1],
                            $colNamesAr2[$i - 1],
                            $keyNamesAr2[$i - 1],
                            $isUniqueAr2[$i - 1] );

        $viewObj->indexCreator();
        $viewObj->requestUpdateCreator();
        $viewObj->requestpagesCreator();    
    
}


mysql_close($conn);
?>
</body>
<html>
