<?php
class config {
    
    public $myParams = array(
        'host' => 'localhost',
        'user' => 'root',
        'pass' => 'mob09363447457',
        'data' => 'zendcrud_db'
    );
}
