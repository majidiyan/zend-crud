<?php
// table name format like: tbl_mytable  tbl_hello  tbl_sara

class modelCreator{
	private $rootUrl;
	function __construct($rootUrl){
		$this->rootUrl = $rootUrl;
	}
	public function dbTable($table){
		$fp = fopen("lib/models/DbTable/Sample.txt","r");
		$str = '';
		
		for($i = 1; $i <= 9; $i++)
		$str = $str.fgets($fp,2000);	
		fclose($fp);
		
                $pdoTable = ucfirst( ltrim($table,'t_') );
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		$str = str_replace('Admin_Model_DbTable_Pages', 'Admin_Model_DbTable_'.$pdoTable, $str);
		
		$strAr = explode("/*part_1*/", $str);
		$strAr[1] = str_replace('tbl_pages', $table, $strAr[1]);
		$output = implode("/*part_1*/", $strAr);
		$output = str_replace("/*part_1*/", "", $output);
		
		$fp = fopen( "output/models/DbTable/".$pdoTable.".php","w+");
		fwrite($fp, $output);
		fclose($fp);
		
	}
	
	public function model($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
		$fp = fopen("lib/models/Sample.txt","r");
		$str = '';
		for($i = 1; $i <= 133; $i++)
			$str = $str.fgets($fp,2000);
		fclose($fp);
		
		$part1 = '';
		
		foreach ($colNamesAr1 as $m)
			$part1.= 'protected $_'.$m.';'."\r\n";
		
		$part2 = '';
		$j = -1;
		foreach ($colNamesAr1 as $m)
		{ 
			$j++;
			$pk = false;
                         // ======== M ======================
                        if( strstr($m, 't_' ) ){
                            $auxAr = explode( 't_', $m  );
                            $M0 = $auxAr[1];}else $M0 = $m;
                            $auxAr = explode('_',$M0);
                            $M='';
                            foreach ($auxAr as $value) 
                                $M.= ucfirst($value);
                       //======== M End ===================
			if( in_array($m, $colNamesAr2)  )
			{
				$k = array_search($m, $colNamesAr2);
				if($keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
			}
			if($pk){
				$part2.= "
						public function set".$M."(\$id)   \r\n
						    {	\r\n
						    	\$this->_".$m." = (int) \$id; \r\n
						    } \r\n
						    \r\n
						public function get".$M."() \r\n
						    {	\r\n
						    	return \$this->_".$m.";  \r\n
						    }   \r\n
						";
				
			}//pk
			else{
				if( strstr('int',strval($colTypesAr1[$j]) ) )
				{
					$part2.= "
							
							public function set".$M."(\$intiger)  \r\n
							    {									\r\n
							    	\$this->_".$m." = (int) \$intiger;  \r\n
							    }		\r\n
							    \r\n
							    public function get".$M."() \r\n
							    {		\r\n
							    	return \$this->_".$m.";  \r\n
							    }	\r\n
							
							";
				}else{
					$part2.= "
							public function set".$M."(\$text) \r\n
							    { \r\n
							    	\$this->_".$m." = (string) \$text; \r\n
							    } \r\n
							    \r\n
							    public function get".$M."() \r\n
							    { \r\n
							    	return \$this->_".$m."; \r\n
							    } \r\n
							
							";
					
				}
				
				
				
				
			}// !pk
			
			
		}//part2
		
                $pdoTable = ucfirst( ltrim($table,'t_') );
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		$str = str_replace('Admin_Model_Pages', 'Admin_Model_'.$pdoTable, $str);
		
		$strCutAr1 = explode("/*part_1*/", $str);
        $str = $strCutAr1[0].$part1.$strCutAr1[2];
        
        $strCutAr2 = explode("/*part_2*/", $str);
        $str = $strCutAr2[0].$part2.$strCutAr2[2];
        
        $fp = fopen( "output/models/".$pdoTable.".php","w+");
        fwrite($fp, $str);
        fclose($fp);
		
		
	}//model
	
	public function mapper($table, $colNamesAr1, $colTypesAr1, $colNamesAr2, $keyNamesAr2, $isUniqueAr2){
		
		$fp = fopen("lib/models/SampleMapper.txt","r");
		$str = '';
		for($i = 1; $i <= 66; $i++)
			$str = $str.fgets($fp,2000);
		fclose($fp);
		
		
		
		$pdoTable = ucfirst( ltrim($table,'t_') );
		$pdoTable = ucfirst( ltrim($table,'tbl_') );
		$str = str_replace("Admin_Model_PagesMapper", "Admin_Model_".$pdoTable."Mapper", $str);
		
		$part1 = $part2 = $part3 = $part4 = $part5 = '';
		
		$part1 = "\$this->setDbTable('Admin_Model_DbTable_".$pdoTable."');";
		
		$part2 = "public function save(Admin_Model_".$pdoTable." \$maillist)";
		
		$part3 = "\$data = array(  \r\n ";
		
		$pkCol = null;
		foreach ($colNamesAr1 as $m)
		{
			//***************** is pk ?
			$pk = false;
                       // ======== M ======================
                        if( strstr($m, 't_' ) ){
                            $auxAr = explode( 't_', $m  );
                            $M0 = $auxAr[1];}else $M0 = $m;
                            $auxAr = explode('_',$M0);
                            $M='';
                            foreach ($auxAr as $value) 
                                $M.= ucfirst($value);
                       //======== M End ===================
                            
			if( in_array($m, $colNamesAr2)  )
			{
				$k = array_search($m, $colNamesAr2);
				if($keyNamesAr2[$k] == 'PRIMARY')
					$pk = true;
					
                       // ======== pkCol ======================
                        if( strstr($m, 't_' ) ){
                            $auxAr = explode( 't_', $m  );
                            $M0 = $auxAr[1];}else $M0 = $m;
                            $auxAr = explode('_',$M0);
                            $M='';
                            foreach ($auxAr as $value) 
                                $M.= ucfirst($value);
                                $pkCol = $M;
                                $pkcol = $m;
                       //======== pkCol End ===================
			}
			//***************** is pk ? end
			if(!$pk)
				$part3.="'".$m."' => \$maillist->get".$M."(),\r\n";
		}//colNamesAr1
		
		$part3 = rtrim($part3, ",\r\n")."\r\n );";
		
		$part4 = "
				 if ( !( (\$id = \$maillist->get".(ucfirst($pkCol))."()) > 0)  ) {
            unset(\$data['".$pkcol."']);
            \$this->getDbTable()->insert(\$data);
        } else {
            \$this->getDbTable()->update(\$data, array('".$pkcol." = ?' => \$id));
        }
				";
		
		$part5 = "
	public function del(Admin_Model_".$pdoTable." \$maillist)
	{
		\$id = \$maillist->get".$pkCol."();
		\$this->getDbTable()->delete( array('".$pkcol." = ?' => \$id));
	}//del
				";
		
		$auxAr = explode("/*part_1*/",$str);
		$str = $auxAr[0].$part1.$auxAr[2];
		
		$auxAr = explode("/*part_2*/",$str);
		$str = $auxAr[0].$part2.$auxAr[2];
		
		$auxAr = explode("/*part_3*/",$str);
		$str = $auxAr[0].$part3.$auxAr[2];
		
		$auxAr = explode("/*part_4*/",$str);
		$str = $auxAr[0].$part4.$auxAr[2];
		
		$auxAr = explode("/*part_5*/",$str);
		$str = $auxAr[0].$part5.$auxAr[2];
		
		$fp = fopen( "output/models/".$pdoTable."Mapper.php","w+");
		fwrite($fp, $str);
		fclose($fp);
	
	}//mapper
	
	
	
}