<html>
    <head>
        <title>page title</title>
        <meta charset="UTF-8" />   
    </head>
    <body>
<?php


$conn = mysql_connect('localhost','root','mob09363447457');
$dbname = 'kanoonar_tashrihi';
mysql_select_db($dbname);

$result = mysql_query("SHOW TABLES FROM $dbname");
$numTables = mysql_num_rows($result);

echo "<dl>";
for($i=1; $i<=$numTables;$i++){
$row = mysql_fetch_row($result);
echo "<dt>".$row[0]."</dt>";
	$sql2 = "SHOW COLUMNS FROM ".$row[0]." ";
	$result2 = mysql_query($sql2);
	$n2 = mysql_num_rows($result2);
	//check for id field name
			$row2=mysql_fetch_array($result2);
			$isId = ($row2['Field']=='id')?true:false;
			mysql_data_seek($result2, 0);			
	//check for id field name end
	
	$fieldsAr = array();
	for($j=1; $j<=$n2; $j++){
		$row2=mysql_fetch_array($result2);
		echo "<dd>".$row2['Field']." <font color=\"red\">".$row2['Type']."</font>"."</dd>";	
	}//j	
}//i
echo "</dl><hr />";


mysql_data_seek($result, 0);
echo "<dl>";
for($i=1; $i<=$numTables;$i++){
	$row = mysql_fetch_row($result);
	echo "<dt>".$row[0]."</dt>";
	$sql2 = "SHOW KEYS FROM ".$row[0]." ";
	$result2 = mysql_query($sql2);
	$n2 = mysql_num_rows($result2);

	$row2=mysql_fetch_array($result2);
		
	mysql_data_seek($result2, 0);

	$fieldsAr = array();
	for($j=1; $j<=$n2; $j++){
		$row2=mysql_fetch_array($result2);
		echo "<dd>".$row2['Key_name']." <font color=\"red\">".$row2['Column_name']."</font> <font color=\"green\">".$row2['Non_unique']."</font>"."</dd>";
	}//j


}//i
echo "</dl>";

mysql_close($conn);
?>
</body>
<html>
